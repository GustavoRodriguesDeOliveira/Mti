<?php

    require_once('Conexao.php');

    class Cadastrofu{
        
        public function cadastrares(
           Conexao $conexao, 
           string $nomeDaTabela, 
           string $codigo,
           string $nomef,
           string $telefone,
           string $sexo,
           string $bairro,
           string $salario)
        {
            try{
                $conn = $conexao->conectar();//Abrindo a conexão com o banco
                $sql  = "insert into $nomeDaTabela (codigo, nomef, telefone, sexo, bairro, salario) 
                values ('','$nomef','$telefone','$sexo','$bairro','$salario')";//Escrevi o script
                $result = mysqli_query($conn,$sql);//Executa a ação do script no banco

                mysqli_close($conn);//fechando a conexão com sucesso!
                
                if($result){
                    return "<br><br>Inserido com sucesso!";
                }
                return "<br><br>Não Inserido!";
            }catch(Except $erro){
                echo $erro;
            }
        }//fim do cadastrar
    }//fim da classe
?>
