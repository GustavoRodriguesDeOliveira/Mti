<?php


    require_once('Conexao.php');


    class Consultar{

        public function consultarIndividual(
            Conexao $conexao, 
            string $nomeDaTabela,
            int $codigo)
        {
            try{
                $conn   = $conexao->conectar();
                $sql    = "select * from $nomeDaTabela where  = '$codigo'";
                $result = mysqli_query($conn,$sql);
                
                while($dados = mysqli_fetch_Array($result)){
                    if($dados["Codigo"] == $codigo){
                        echo "<br>Código: ".$this->codigo."<br>Nome do cliente: ".$this->nome."<br>Data da compra: ".$this->datac."<br>Qual é o produto: ".$this->produto."<br>Quantos produtos: ".$this->quantidade."<br>Valor do produto: ".$this->valorc;
                        return;//Encerrar a operacao
                    }//fim do if
                }//fim do while
                echo "Codigo digitado não foi encontrado!";
            }
            catch(Except $erro)
            {
                echo $erro;
            } 
        }//fim do método


        public function consultarTudo(Conexao $conexao, string $nomeDaTabela){
            try{
                $conn   = $conexao->conectar();
                $sql    = "select * from $nomeDaTabela";
                $result = mysqli_query($conn,$sql);
                
                while($dados = mysqli_fetch_Array($result)){
                    echo "<br>Código: ".$this->codigo."<br>Nome do cliente: ".$this->nome."<br>Data da compra: ".$this->datac."<br>Qual é o produto: ".$this->produto."<br>Quantos produtos: ".$this->quantidade."<br>Valor do produto: ".$this->valorc;
                }//fim do while
            }
            catch(Except $erro)
            {
                echo $erro;
            } 
        }//fim do método

    }//fim do consultar
?>