<?php

    require_once('Conexao.php');

    class Cadastroes{
        
        public function cadastrares(
           Conexao $conexao, 
           string $nomeDaTabela, 
           string $codigo,                                               
           string $nomep,
           string $datav,
           string $quantidadep,
           string $valorp)
        {
            try{
                $conn = $conexao->conectar();//Abrindo a conexão com o banco
                $sql  = "insert into $nomeDaTabela (codigo, nome, datav, quantidadep, valorp) 
                values ('','$nomep','$datav','$quantidadep','$valorp')";//Escrevi o script
                $result = mysqli_query($conn,$sql);//Executa a ação do script no banco

                mysqli_close($conn);//fechando a conexão com sucesso!
                
                if($result){
                    return "<br><br>Inserido com sucesso!";
                }
                return "<br><br>Não Inserido!";
            }catch(Except $erro){
                echo $erro;
            }
        }//fim do cadastrar
    }//fim da classe
?>
