<?php

    require_once('Conexao.php');

    class Cadastro{
        
        public function cadastrar(
            Conexao $conexao, 
            string $nomeDaTabela, 
            string $codigo,
             string $nome,
             string $datac,
             string $produto,
             string $quantidade,
             string $valorc)
        {
            try{
                $conn = $conexao->conectar();//Abrindo a conexão com o banco
                $sql  = "insert into $nomeDaTabela (codigo, nome, datac, produto, quantidade, valorc) 
                values ('','$nome','$datac','$produto','$quantidade','$valorc')";//Escrevi o script
                $result = mysqli_query($conn,$sql);//Executa a ação do script no banco

                mysqli_close($conn);//fechando a conexão com sucesso!
                
                if($result){
                    return "<br><br>Inserido com sucesso!";
                }
                return "<br><br>Não Inserido!";
            }catch(Except $erro){
                echo $erro;
            }
        }//fim do cadastrar
    }//fim da classe
?>