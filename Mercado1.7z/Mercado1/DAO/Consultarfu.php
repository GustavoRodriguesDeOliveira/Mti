<?php


    require_once('Conexao.php');


    class Consultarfu{

        public function consultarIndividual(
            Conexao $conexao, 
            string $nomeDaTabela,
            int $codigo)
        {
            try{
                $conn   = $conexao->conectar();
                $sql    = "select * from $nomeDaTabela where  = '$codigo'";
                $result = mysqli_query($conn,$sql);
                
                while($dados = mysqli_fetch_Array($result)){
                    if($dados["CPF"] == $cpf){
                        echo "<br>Código: ".$this->codigo."<br>Nome do : ".$this->nome."<br>Telefone: ".$this->telefone."<br>Sexo: ".$this->sexo."<br>Bairro: ".$this->bairro."<br>Salário: ".$this->salario;
                        return;//Encerrar a operacao
                    }//fim do if
                }//fim do while
                echo "CPF digitado não foi encontrado!";
            }
            catch(Except $erro)
            {
                echo $erro;
            } 
        }//fim do método


        public function consultarTudo(Conexao $conexao, string $nomeDaTabela){
            try{
                $conn   = $conexao->conectar();
                $sql    = "select * from $nomeDaTabela";
                $result = mysqli_query($conn,$sql);
                
                while($dados = mysqli_fetch_Array($result)){
                    echo "<br>Código: ".$this->codigo."<br>Nome do : ".$this->nome."<br>Telefone: ".$this->telefone."<br>Sexo: ".$this->sexo."<br>Bairro: ".$this->bairro."<br>Salário: ".$this->salario;
                }//fim do while
            }
            catch(Except $erro)
            {
                echo $erro;
            } 
        }//fim do método

    }//fim do consultar
?>