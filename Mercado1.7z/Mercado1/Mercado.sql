create database Mercado2;

use mercado2;

create table cadastro(
  codigo int not null primary key auto_increment,
  nome varchar(100) not null,
  datac date not null,
  produto varchar(20) not null,
  quantidade int not null,
  valorc decimal(5,2) not null
)engine = InnoDB;

create table estoque(
  codigo int not null primary key auto_increment,
  nomep varchar(20) not null,
  quantidadep int not null,
  datav date not null,
  valorp decimal(5,2) not null
)engine = InnoDB;

create table funcionario(
  codigo int not null primary key auto_increment,
  nomef varchar(20) not null,
  telefone varchar(9) not null,
  sexo varchar(1) not null,
  bairro varchar(100) not null,
  salario decimal(5,2) not null
)engine = InnoDB;

create table gerente(
  codigo int not null primary key auto_increment,
  nomeg varchar(20) not null,
  telefoneg varchar(9) not null,
  sexog varchar(1) not null,
  bairrog varchar(100) not null,
  salariog decimal(5,2) not null
)engine = InnoDB;